package Main2014302580307;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2014302580307 {
	public static void main(String args[]) throws IOException{
		//��Jsoup����url
		Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Hao%20Huang").get();
		String title = doc.title();
		//��ȡ����
		Elements name = doc.getElementsByClass("title");
		String name1 = name.text();
		//��ȡ���
		Element ResDir = doc.select("p").first();
		String ResDir1 = ResDir.text();
		//������ժȡemail
		String email = null;
		Pattern p1 =Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		Matcher m1 =p1.matcher(ResDir1);
		while(m1.find()){
			email = m1.group();
		}
		//������ժȡ�绰
		String telnumber = null;
		Pattern p2=Pattern.compile("[0-9]+\\-+[0-9]{8}");
		Matcher m2=p2.matcher(ResDir1);
		while(m2.find()){
			telnumber = m2.group();
		}
		//���txt
		File teacher=new File("teacher.txt");
		PrintWriter pfp = new PrintWriter(teacher);
		pfp.print(name1);
		pfp.print(telnumber);
		pfp.print(email);
		pfp.print(ResDir1);
		pfp.close();
	}
}
